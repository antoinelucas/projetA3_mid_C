#include "define.h"

void integrationTest(int regul,temp_t tInit,int nIterations);