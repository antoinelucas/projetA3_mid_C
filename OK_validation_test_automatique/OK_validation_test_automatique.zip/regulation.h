#include "define.h" 

float regulationTest(int regul,float csgn,float* tabT, int nT);
float regulation(int regul, float csgn, float valueTemp,SPID * pid,int i);