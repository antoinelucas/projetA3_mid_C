#include "define.h"

#define TAILLE_MAX 5 // Tableau de taille 5

float consigne(float csgn);