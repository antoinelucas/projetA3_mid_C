#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "define.h"
#include "simulateur.h"

#define CONSIGNE 0

void integrationTest(int regul,temp_t tInit,int nIterations);