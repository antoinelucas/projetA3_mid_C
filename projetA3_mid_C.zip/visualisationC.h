
void visualisationC(float puissance_f);